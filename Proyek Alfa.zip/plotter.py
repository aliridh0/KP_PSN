import matplotlib.pyplot as plt

def plot_data(data_df):
    # Plot hubungan waktu dengan gain
    plt.figure(figsize=(12, 6))
    plt.plot(data_df['waktu'], data_df['gain'], label='Gain')
    plt.xlabel('Waktu')
    plt.ylabel('Gain')
    plt.title('Grafik Hubungan Waktu dengan Gain')
    plt.legend()
    plt.show()

def plot_data1(data_df):
    # Plot hubungan waktu dengan power out
    plt.figure(figsize=(12, 6))
    plt.plot(data_df['waktu'], data_df['power_out'], label='Gain')
    plt.xlabel('Waktu')
    plt.ylabel('Power Out')
    plt.title('Grafik Hubungan Waktu dengan Power Out')
    plt.legend()
    plt.show()


    