from dtp_translator import load_dtp_subchannel, translate_port
from file_finder import find_csv_file
from data_processor import read_csv_data, process_data, process_data1
from plotter import plot_data, plot_data1
from utils import get_user_input

def main():
    # Load DTP Subchannel data
    dtp_df = load_dtp_subchannel('DTP subchannel.xlsx')
    
    while True:
        # Get user input
        logical_port, subchannel = get_user_input()
        
        # Translate Logical_OutputPort to Physical_OutputPort
        physical_port = translate_port(logical_port, dtp_df)
        if physical_port is None:
            print(f"Physical_OutputPort untuk {logical_port} tidak ditemukan.")
            continue
        
        # Find the corresponding CSV file
        file_path = find_csv_file('TEMP_OUTPUT_PWR240624', physical_port, subchannel)
        if file_path is None:
            print(f"File CSV untuk {physical_port}_{subchannel} tidak ditemukan.")
            continue
        
        # Read and process data from CSV file
        data_df = read_csv_data(file_path)
        processed_data_df = process_data(data_df)
        processed_data1_df = process_data1(data_df)
        
        # Plot data
        plot_data(processed_data_df)
        plot_data1(processed_data1_df)
        break

if __name__ == "__main__":
    main()
