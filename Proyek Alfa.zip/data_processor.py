import pandas as pd

def read_csv_data(file_path):
    # Membaca file CSV tanpa baris header
    data_df = pd.read_csv(file_path, header=None, names=['waktu', 'power_out', 'gain'])
    
    # Memastikan kolom 'waktu' diinterpretasikan sebagai tanggal dan waktu
    data_df['waktu'] = pd.to_datetime(data_df['waktu'])
    
    return data_df

def process_data(data_df):
    # Lakukan proses pengolahan data di sini
    # Contoh sederhana: hanya mengambil kolom waktu dan gain
    processed_data_df = data_df[['waktu', 'gain']]  # Sesuaikan dengan struktur data yang sesuai
    return processed_data_df

def process_data1(data_df):
    # Lakukan proses pengolahan data di sini
    # Contoh sederhana: hanya mengambil kolom waktu dan gain
    processed_data1_df = data_df[['waktu', 'power_out']]  # Sesuaikan dengan struktur data yang sesuai
    return processed_data1_df

