import os

def find_csv_file(folder_path, physical_port, subchannel):
    file_name = f"{physical_port}_{subchannel}.csv"
    file_path = os.path.join(folder_path, file_name)
    if os.path.exists(file_path):
        return file_path
    else:
        return None
