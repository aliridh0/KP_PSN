import plotly.graph_objs as go

def plot_data(data_df):
    # Plot untuk Gain dBW terhadap Waktu
    fig_gain = go.Figure()
    fig_gain.add_trace(go.Scatter(x=data_df['waktu'], y=data_df['gain_dBW_total'], mode='lines', name='Gain dBW Total', line=dict(color='blue')))
    fig_gain.update_layout(
        title='Gain dBW Total terhadap Waktu dalam Rentang 7 Menit 42 Detik',
        xaxis_title='Waktu',
        yaxis_title='Gain dBW Total',
        showlegend=True,
        hovermode='x'
    )
    plot_html_gain = fig_gain.to_html(full_html=False)

    # Plot untuk Power Output dBW terhadap Waktu
    fig_power = go.Figure()
    fig_power.add_trace(go.Scatter(x=data_df['waktu'], y=data_df['power_out_dBW_total'], mode='lines', name='Power Output dBW Total', line=dict(color='green')))
    fig_power.update_layout(
        title='Power Output dBW Total terhadap Waktu dalam Rentang 7 Menit 42 Detik',
        xaxis_title='Waktu',
        yaxis_title='Power Output dBW Total',
        showlegend=True,
        hovermode='x'
    )
    plot_html_power = fig_power.to_html(full_html=False)

    return plot_html_gain, plot_html_power
