import os

def save_combined_data(data_df, output_folder, check_folder, logical_port):
    # Pastikan folder output dan check ada
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)
    if not os.path.exists(check_folder):
        os.makedirs(check_folder)
    
    # Path untuk output dan check folder
    combined_file_path_output = os.path.join(output_folder, f"{logical_port}_combined.csv")
    combined_file_path_check = os.path.join(check_folder, f"{logical_port}_combined.csv")
    
    # Simpan ke kedua folder
    data_df.to_csv(combined_file_path_check, index=False)
    
    return combined_file_path_output, combined_file_path_check
