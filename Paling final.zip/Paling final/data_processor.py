import pandas as pd
import numpy as np

def read_csv_data(file_path):
    # Membaca file CSV tanpa baris header, dan menambahkan nama kolom 'waktu', 'power_out', dan 'gain'
    data_df = pd.read_csv(file_path, header=None, names=['waktu', 'gain', 'power_out'])

    # Mengubah kolom 'waktu' menjadi tipe data datetime
    data_df['waktu'] = pd.to_datetime(data_df['waktu'])
    return data_df

def process_data(data_df, chunk_size):
    # Menghitung gain dan power output dalam dBW
    data_df['gain_dBW'] = data_df['gain']
    data_df['power_out_dBW'] = data_df['power_out'] - 30

    # Menghitung gain dan power output numerik
    data_df['gain_numerik'] = (10 ** ((data_df['gain_dBW']) / 10))
    data_df['power_out_numerik'] = (10 ** (data_df['power_out_dBW'] / 10))

    # Mengambil data waktu awal data ditemukan
    waktu_awal = data_df['waktu'].iloc[0]

    # Urutkan data berdasarkan waktu
    data_df.sort_values(by='waktu', inplace=True)

    print(f"Total data length: {len(data_df)}")  # Log jumlah data awal

    # Buat list untuk menampung hasil penjumlahan setiap chunk_size data
    results = []
    for start in range(0, len(data_df), chunk_size):
        end = start + chunk_size
        chunk = data_df.iloc[start:end].drop(columns=['waktu']).sum()
        results.append(chunk)
        print(f"Processing chunk from {start} to {end}")  # Log chunk yang diproses

    # Buat DataFrame dari hasil penjumlahan
    result_df = pd.DataFrame(results)

    # Menghitung gain dan power output dalam dBW dari hasil penjumlahan
    result_df['gain_dBW_total'] = 10 * np.log10(result_df['gain_numerik'])
    result_df['power_out_dBW_total'] = 10 * np.log10(result_df['power_out_numerik'])

    # Menambahkan kolom waktu dengan interval 7menit 42 detik dimulai dari data pertama diambil
    result_df['waktu'] = pd.date_range(start=waktu_awal, periods=len(result_df), freq='7min 42s')

    return result_df.reset_index(drop=True)
