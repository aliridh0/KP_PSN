from flask import Flask, render_template, request, redirect, url_for, flash
from dtp_translator import load_dtp_subchannel, translate_port
from file_finder import find_csv_files, save_combined_csv
from data_processor import read_csv_data, process_data
from plotter import plot_data
import os
import pandas as pd
from save_combined_data import save_combined_data

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Load DTP Subchannel data
dtp_df = load_dtp_subchannel('DTP subchannel.xlsx')

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        logical_port_number = request.form['logical_port']
        logical_port = f"DTPO-{logical_port_number}"

        # Tentukan chunk_size berdasarkan nilai logical_port_number
        if (logical_port_number =='27'):
            chunk_size = 1
        elif (logical_port_number =='24'):
            chunk_size = 6
        elif (logical_port_number =='08'):
            chunk_size = 7
        elif (logical_port_number =='03'):
            chunk_size = 8
        elif (logical_port_number =='19') or (logical_port_number =='22') or (logical_port_number =='30'):
            chunk_size = 9
        elif (logical_port_number =='09') or (logical_port_number =='06'):
            chunk_size = 10
        elif (logical_port_number =='17') or (logical_port_number =='11') or (logical_port_number =='14'):
            chunk_size = 11
        elif (logical_port_number =='15') or (logical_port_number =='31') or (logical_port_number =='32'):
            chunk_size = 12
        elif (logical_port_number =='01') or (logical_port_number =='07'):
            chunk_size = 15
        elif (logical_port_number =='20'):
            chunk_size = 16
        elif (logical_port_number =='12'):
            chunk_size = 17
        elif (logical_port_number =='02') or (logical_port_number =='29') or (logical_port_number =='04') or (logical_port_number =='21'):
            chunk_size = 18
        elif (logical_port_number =='25') or (logical_port_number =='05'):
            chunk_size = 19
        elif (logical_port_number =='16') or (logical_port_number =='28'):
            chunk_size = 20
        elif (logical_port_number =='10'):
            chunk_size = 23
        elif (logical_port_number =='13'):
            chunk_size = 24
        elif (logical_port_number =='18'):
            chunk_size = 54
        elif (logical_port_number =='26'):
            chunk_size = 64 
        else:
            chunk_size = 78  # Default chunk size untuk DTPO-23

        print(f"Chunk size for logical port {logical_port_number}: {chunk_size}")  # Log chunk size

        # Translate Logical_OutputPort to Physical_OutputPort
        physical_port = translate_port(logical_port, dtp_df)
        if physical_port is None:
            flash(f"Physical_OutputPort untuk {logical_port} tidak ditemukan.", 'error')
            return redirect(url_for('index'))

        # Find all corresponding CSV files for the Physical_OutputPort
        file_paths = find_csv_files('TEMP_OUTPUT_PWR', physical_port)
        if not file_paths:
            flash(f"Tidak ada file CSV untuk {physical_port} ditemukan.", 'error')
            return redirect(url_for('index'))

        # Read and process data from all CSV files
        combined_data_df = pd.DataFrame()
        for file_path in file_paths:
            data_df = read_csv_data(file_path)
            combined_data_df = pd.concat([combined_data_df, data_df], ignore_index=True)

        # Save combined data to both output and check folders
        output_folder = 'Combined_Output'
        check_folder = 'Combined_Check'
        combined_file_path_output, combined_file_path_check = save_combined_data(combined_data_df, output_folder, check_folder, logical_port)

        processed_data_df = process_data(combined_data_df, chunk_size)

        # Save processed data to new CSV file
        processed_combined_file_path = save_combined_csv(processed_data_df, output_folder, physical_port)

        # Plot data using Plotly
        plot_html_gain, plot_html_power = plot_data(processed_data_df)

        flash(f"Data berhasil diproses untuk {logical_port} atau Physical port {physical_port}.",'success')
        return render_template('index.html', plot_html_gain=plot_html_gain, plot_html_power=plot_html_power)

    return render_template('index.html')


if __name__ == '__main__':
    app.run(debug=True)
