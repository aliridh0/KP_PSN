import os
import re

def find_csv_files(folder_path, physical_port):
    physical_port = str(physical_port)  # Pastikan physical_port adalah string
    pattern = re.compile(rf"^{physical_port}(?!\d)")  # Buat regex untuk mencocokkan physical_port diikuti bukan angka
    files = []
    for file_name in os.listdir(folder_path):
        if pattern.match(file_name) and file_name.endswith('.csv'):
            files.append(os.path.join(folder_path, file_name))
    return files


def save_combined_csv(data_df, output_folder, physical_port):
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)
    combined_file_path = os.path.join(output_folder, f"{physical_port}.csv")
    data_df.to_csv(combined_file_path, index=False)
    return combined_file_path
